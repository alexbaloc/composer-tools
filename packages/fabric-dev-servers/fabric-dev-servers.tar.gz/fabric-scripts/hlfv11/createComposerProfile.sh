#!/bin/bash

# Exit on first error, print all commands.
echo "Not available on this level of fabric."